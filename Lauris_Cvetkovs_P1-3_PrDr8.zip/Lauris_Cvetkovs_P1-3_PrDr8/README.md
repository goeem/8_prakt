horoskops uz 2024. gadu
    Šis rīks balstoties uz lietotāja ievadīto mēnesi, nosaka tā horoskopu uz visu 2024. gadu, balstoties uz https://www.la.lv/lielais-gada-horoskops-2024-gadam-garlaicigi-nebus-nevienam.

Iespējamie uzlabojumi
    Balstīt atbildes ne tikai uz mēnesi, bet, piemēram, arī uz dzimšanas laiku.
    Pievienot neirotīklu, kas ģenerētu atbildes pats.
Problēmas
    Nav zināmu problēmu
Autori
    2024: Lauris Cvetkovs